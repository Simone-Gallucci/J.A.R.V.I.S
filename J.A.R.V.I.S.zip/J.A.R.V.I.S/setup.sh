#!/bin/bash

echo "Avvio setup di Jarvis..."

# Aggiorna pacchetti
echo "Aggiornamento pacchetti..."
apt update && apt upgrade -y

# Installa python e pip
echo "Installazione Python e pip..."
apt install -y python3 python3-pip

# Installa le librerie necessarie
echo "Installazione librerie Python..."
pip install --break-system-packages python-telegram-bot openai

# Rendi eseguibili i file .sh
echo "Impostazione permessi eseguibili..."
chmod +x setup.sh

echo "Setup completato. Ora puoi avviare Jarvis!"
