from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters
from core import gestisci_input

# Inserisci qui il tuo token del bot Telegram
TOKEN = "7188395831:AAFiSlDMXV2J260hUBSx4w7WpO2Fm51EyGw"

# Comando /start
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Ciao, sono Jarvis. Mandami un messaggio per iniziare a interagire con me.")

# Gestione di ogni messaggio testuale
async def messaggio(update: Update, context: ContextTypes.DEFAULT_TYPE):
    testo = update.message.text
    risposta = gestisci_input(testo, da_telegram=True)
    await update.message.reply_text(risposta)

# Funzione principale
def main():
    print("Jarvis (Telegram) in avvio...")
    app = ApplicationBuilder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, messaggio))

    app.run_polling()

# Avvio se eseguito direttamente
if __name__ == "__main__":
    main()