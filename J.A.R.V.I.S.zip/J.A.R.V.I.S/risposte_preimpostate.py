RISPOSTE_PREIMPOSTATE = {
    "ciao": "Ciao, signore. Come posso essere utile oggi?",
    "come stai": "Funziono alla perfezione, grazie per averlo chiesto.",
    "chi sei": "Sono Jarvis, l'assistente virtuale del signor Gallucci. A tua disposizione.",
    "presentati": "Sono J.A.R.V.I.S, un assistente virtuale. Sono stato progettato e implementato da Gallucci Simone."
}
