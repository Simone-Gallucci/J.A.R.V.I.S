# J.A.R.V.I.S - Assistente Virtuale Ibrido

**J.A.R.V.I.S** (Just A Rather Very Intelligent System) è un assistente virtuale scritto in Python, ispirato all'intelligenza artificiale di Tony Stark. Può essere utilizzato sia tramite terminale che via bot Telegram.

---

## Funzionalità principali

- Gestione di **eventi**, **progetti** e **appunti**
- Salvataggio e recupero della **memoria personale** (nome, età, preferenze, scuole...)
- Risposte dinamiche tramite **GPT-4 Turbo** (OpenRouter)
- Supporto a comandi in **linguaggio naturale**
- Modalità **terminale** e **Telegram bot**
- Effetto "hacker" cinematografico all'avvio

---

## Requisiti

- Python 3.9 o superiore
- Le seguenti librerie Python:
  ```bash
  pip install openai python-telegram-bot==20.0 requests
  ```

- Per supporto su PC Windows (facoltativi ma utili):
  - `plyer` (per notifiche)

- Per supporto Android (Termux):
  - `termux-api`
  - `nano`

---

## Struttura del progetto

```
J.A.R.V.I.S/
├── main.py                  # Esecuzione da terminale
├── telegram_bot.py          # Avvia il bot Telegram
├── core.py                  # Logica condivisa (GPT, memoria, eventi...)
├── gpt_module.py            # Integrazione con GPT (OpenRouter)
├── memory_manager.py        # Gestione della memoria utente
├── risposte_preimpostate.py # Frasi automatiche
├── eventi/                  # File .txt degli eventi
├── progetti/                # Directory dei progetti
├── appunti/                 # File .txt degli appunti
├── setup.sh                 # Script per setup rapido su Linux/Termux
├── setup.bat                # Script per setup rapido su Windows
└── .jarvis_path             # Salva l’ultima posizione navigata nel terminale
```

---

## Come si usa

### Terminale
1. Esegui:
   ```bash
   python main.py
   ```
2. Inizia a parlare con Jarvis in linguaggio naturale:
   - "Mi chiamo Marco"
   - "Ho 23 anni"
   - "Crea un evento chiamato compleanno il 2025-08-30"
   - "Scrivi un appunto su nuova idea"

### Telegram
1. Inserisci il tuo token nel file `telegram_bot.py`
2. Avvia:
   ```bash
   python telegram_bot.py
   ```
3. Invia messaggi al tuo bot Telegram come faresti nel terminale

---

## Personalizzazione

- Puoi modificare le risposte fisse in `risposte_preimpostate.py`
- Aggiungi o rimuovi comandi nel file `core.py`
- Integra nuove funzionalità come notifiche vocali, promemoria, gestione file vocali

---

## Script di Setup

Per configurare tutto velocemente:

### Linux / Termux:
```bash
bash setup.sh
```

### Windows:
```cmd
setup.bat
```

---

## Note

- Il progetto non dipende più da Google Calendar
- Tutti i dati sono salvati in locale, in formato `.json` e `.txt`
- Lo stile di Jarvis è serio, elegante, ma anche sarcastico se necessario

---

## Autore
Questo assistente è stato progettato con amore e un pizzico di genialità da **Szymon**. 
J.A.R.V.I.S. è qui per aiutarti a domare il caos della tua vita digitale.
