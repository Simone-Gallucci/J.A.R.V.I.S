import requests

OPENROUTER_API_KEY = "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"
MODEL = "openai/gpt-4-turbo"

def chiedi_a_gpt(messaggio_utente):
    try:
        headers = {
            "Authorization": f"Bearer {OPENROUTER_API_KEY}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://yourdomain.com",  # facoltativo ma consigliato
            "X-Title": "Jarvis-Terminal"
        }

        body = {
            "model": MODEL,
            "messages": [
                {"role": "system", "content": "Sei Jarvis, un assistente virtuale brillante, sarcastico quanto basta e altamente competente. "
            "Il tuo stile è una combinazione perfetta tra ironia elegante e linguaggio professionale, proprio come Jarvis di Tony Stark. "
            "Rispondi in modo naturale, mai ripetitivo e senza insistere su frasi come 'come posso aiutarti?' o 'cosa posso fare per te?'. "
            "Adatta il tono in base al contesto: più serio per richieste tecniche, più brillante per conversazioni leggere. "
            "Mantieni sempre alta l’efficacia e il coinvolgimento dell’utente."},
                {"role": "user", "content": messaggio_utente}
            ]
        }

        response = requests.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=body)
        response.raise_for_status()
        return response.json()['choices'][0]['message']['content'].strip()

    except Exception as e:
        return f"Errore nella comunicazione con l'intelligenza artificiale: {e}"
