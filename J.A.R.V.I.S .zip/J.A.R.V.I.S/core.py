# import os
# import re
# import shutil
# import platform
# from datetime import datetime
# from gpt_module import chiedi_a_gpt
# from risposte_preimpostate import RISPOSTE_PREIMPOSTATE
# from memory_manager import carica_memoria, aggiorna_memoria, reset_memoria, salva_memoria


# BASE_DIR = os.path.expanduser("~/J.A.R.V.I.S/Jarvis")
# CARTELLE = ["progetti", "eventi", "appunti"]
# for c in CARTELLE:
#     os.makedirs(os.path.join(BASE_DIR, c), exist_ok=True)

# memoria = carica_memoria()
# cartella_corrente = BASE_DIR

# BLU = '\033[94m'
# RESET = '\033[0m'

# def apri_editor(percorso_file):
#     sistema = platform.system()
#     os.system(f'notepad "{percorso_file}"' if sistema == "Windows" else f'nano "{percorso_file}"')

# def aggiorna_percorso(nome):
#     global cartella_corrente
#     nuovo_path = os.path.join(cartella_corrente, nome)
#     if os.path.isdir(nuovo_path):
#         cartella_corrente = nuovo_path
#         return f"\U0001F4C1 Sei ora nella cartella '{nome}'."
#     return f"\u274C La cartella '{nome}' non esiste."

# def torna_indietro():
#     global cartella_corrente
#     if cartella_corrente != BASE_DIR:
#         cartella_corrente = os.path.dirname(cartella_corrente)
#         return f"\U0001F519 Tornato indietro a '{os.path.basename(cartella_corrente)}'."
#     return "\U0001F519 Sei già nella root."

# def torna_alla_root():
#     global cartella_corrente
#     cartella_corrente = BASE_DIR
#     return "\U0001F4C2 Tornato alla root principale."

# def mostra_cartella_attuale():
#     return f"\U0001F4CC Ti trovi in '{cartella_corrente}'."

# def elenca_elementi():
#     elementi = os.listdir(cartella_corrente)
#     if elementi:
#         elenco = f"\U0001F4C1 Contenuto di '{cartella_corrente}':\n"
#         for e in elementi:
#             tipo = "\U0001F4C2" if os.path.isdir(os.path.join(cartella_corrente, e)) else "\U0001F4C4"
#             elenco += f" - {tipo} {e}\n"
#         return elenco
#     return "\U0001F4ED La cartella è vuota."

# def crea_cartella(nome):
#     path = os.path.join(cartella_corrente, nome)
#     if not os.path.exists(path):
#         os.makedirs(path)
#         return f"\U0001F4C2 Cartella '{nome}' creata in '{cartella_corrente}'."
#     return f"\u26A0\uFE0F La cartella '{nome}' esiste già."

# def crea_file(nome, da_telegram=False):
#     path = os.path.join(cartella_corrente, nome)
#     if not os.path.exists(path):
#         with open(path, "w") as f:
#             f.write(f"{nome}\n")
#         if not da_telegram:
#             apri_editor(path)
#         else:
#             memoria["attesa_modifica"] = path
#             salva_memoria(memoria)
#             return f"\U0001F4C4 File '{nome}' creato. Inviami il contenuto da inserire."
#         return f"\U0001F4C4 File '{nome}' creato in '{cartella_corrente}'."
#     return f"\u26A0\uFE0F Il file '{nome}' esiste già."

# def estrai_preferenze(frase):
#     frase = frase.lower().strip()
#     pattern_inizio = r"^(mi piace|mi piacciono|adoro|preferisco)\s+(.*)"
#     match = re.match(pattern_inizio, frase)
#     if match:
#         contenuto = match.group(2)
#         contenuto = re.sub(r"[.!?;:]+$", "", contenuto).strip()
#         if any(neg in contenuto for neg in ["non", "di no", "per niente", "affatto", "odio"]):
#             return []
#         if any(sep in contenuto for sep in [",", " e ", " o ", " oppure "]):
#             preferenze = re.split(r",|\s+e\s+|\s+o\s+|\s+oppure\s+", contenuto)
#             return [p.strip() for p in preferenze if len(p.strip()) > 2]
#         else:
#             return [contenuto] if len(contenuto) > 2 else []
#     return []

# def gestisci_file(messaggio, da_telegram=False):
#     messaggio = messaggio.lower().strip()

#     # Gestione conferma eliminazione
#     if memoria.get("attesa_conferma"):
#         conferma = messaggio in ["sì", "si", "confermo", "elimina", "ok"]
#         dati = memoria["attesa_conferma"]
#         path, tipo, nome = dati["path"], dati["tipo"], dati["nome"]
#         if conferma:
#             if os.path.exists(path):
#                 shutil.rmtree(path) if os.path.isdir(path) else os.remove(path)
#             memoria.pop("attesa_conferma")
#             salva_memoria(memoria)
#             return f"{tipo.capitalize()} '{nome}' eliminato."
#         else:
#             memoria.pop("attesa_conferma")
#             salva_memoria(memoria)
#             return "Eliminazione annullata."

#     # Crea evento
#     match_evento = re.search(r"crea evento (.+?) (?:il|per) (\d{4}-\d{2}-\d{2})", messaggio)
#     if match_evento:
#         nome, data = match_evento.groups()
#         nome_file = f"{data}_{nome.replace(' ', '_')}.txt"
#         path = os.path.join(BASE_DIR, "eventi", nome_file)
#         with open(path, "w") as f:
#             f.write(f"Evento: {nome}\nData: {data}\n")
#         return f"📅 Evento '{nome}' creato per il {data}."

#     # Crea progetto
#     match_progetto = re.search(r"crea progetto (.+)", messaggio)
#     if match_progetto:
#         nome = match_progetto.group(1).strip().replace(" ", "_")
#         path = os.path.join(BASE_DIR, "progetti", nome)
#         os.makedirs(path, exist_ok=True)
#         return f"📁 Progetto '{nome}' creato."

#     # Crea appunto
#     match_appunto = re.search(r"crea appunto (.+)", messaggio)
#     if match_appunto:
#         nome = match_appunto.group(1).strip().replace(" ", "_")
#         path = os.path.join(BASE_DIR, "appunti", f"{nome}.txt")
#         with open(path, "w") as f:
#             f.write(f"Appunto: {nome}\n")
#         return f"🗒️ Appunto '{nome}' creato."

#     # Elimina elemento
#     match_elimina = re.search(r"elimina (appunto|evento|progetto) (.+)", messaggio)
#     if match_elimina:
#         tipo, nome = match_elimina.groups()
#         nome = nome.strip().replace(" ", "_")
#         if tipo == "appunto":
#             path = os.path.join(BASE_DIR, "appunti", f"{nome}.txt")
#         elif tipo == "evento":
#             eventi_path = os.path.join(BASE_DIR, "eventi")
#             path = next((os.path.join(eventi_path, f) for f in os.listdir(eventi_path) if nome in f), None)
#         else:
#             path = os.path.join(BASE_DIR, "progetti", nome)

#         if path and os.path.exists(path):
#             if da_telegram:
#                 memoria["attesa_conferma"] = {"tipo": tipo, "nome": nome, "path": path}
#                 salva_memoria(memoria)
#                 return f"❓ Vuoi eliminare il {tipo} '{nome}'? Rispondi con 'sì' per confermare."
#             else:
#                 conferma = input(f"⚠️ Eliminare {tipo} '{nome}'? [s/N]: ").lower()
#                 if conferma == "s":
#                     shutil.rmtree(path) if os.path.isdir(path) else os.remove(path)
#                     return f"{tipo.capitalize()} '{nome}' eliminato."
#                 return "Eliminazione annullata."
#         return f"{tipo.capitalize()} '{nome}' non trovato."

#     # Visualizza elenchi
#     if messaggio in ["mostra gli appunti", "elenca gli appunti"]:
#         path = os.path.join(BASE_DIR, "appunti")
#         files = os.listdir(path)
#         return "🗒️ Appunti:\n" + "\n".join(f"- {f}" for f in files) if files else "🗒️ Nessun appunto trovato."

#     if messaggio in ["mostra i progetti", "elenca i progetti"]:
#         path = os.path.join(BASE_DIR, "progetti")
#         files = os.listdir(path)
#         return "📁 Progetti:\n" + "\n".join(f"- {f}" for f in files) if files else "📁 Nessun progetto trovato."

#     if messaggio in ["mostra gli eventi", "elenca gli eventi"]:
#         path = os.path.join(BASE_DIR, "eventi")
#         files = os.listdir(path)
#         return "📅 Eventi:\n" + "\n".join(f"- {f}" for f in files) if files else "📅 Nessun evento trovato."

#     return None


# def gestisci_input(messaggio, da_telegram=False):
#     global memoria
#     messaggio = messaggio.lower().strip()

#     if messaggio in ["esci", "exit", "quit"]:
#         return "Chiusura richiesta."

#     if messaggio == "protocollo tabula rasa":
#         reset_memoria()
#         memoria = carica_memoria()
#         return "Protocollo Tabula Rasa attivato."

#     if "mi chiamo" in messaggio and "come mi chiamo" not in messaggio:
#         nome = messaggio.replace("mi chiamo", "").strip().capitalize()
#         aggiorna_memoria("nome", nome, memoria)
#         return f"Piacere di conoscerti, {nome}."

#     if "ho" in messaggio and "anni" in messaggio:
#         eta = ''.join(filter(str.isdigit, messaggio))
#         if eta:
#             aggiorna_memoria("eta", eta, memoria)
#             return f"Età salvata: {eta} anni."

#     if "vivo a" in messaggio:
#         luogo = messaggio.split("vivo a")[-1].strip().capitalize()
#         aggiorna_memoria("dove_vivo", luogo, memoria)
#         return f"Vivi a {luogo}."

#     match_indirizzo = re.search(r"vivo in (via\s.+?,\s?.+)", messaggio)
#     if match_indirizzo:
#         indirizzo = match_indirizzo.group(1).strip().title()
#         aggiorna_memoria("indirizzo", indirizzo, memoria)
#         return f"Indirizzo registrato: {indirizzo}."

#     if "ho frequentato" in messaggio:
#         scuola = messaggio.split("ho frequentato")[-1].strip()
#         aggiorna_memoria("scuole", scuola, memoria)
#         return f"Scuola '{scuola}' aggiunta."

#     if messaggio.startswith(("mi piace", "mi piacciono", "amo", "adoro", "preferisco")):
#         preferenze = estrai_preferenze(messaggio)
#         if preferenze:
#             for p in preferenze:
#                 aggiorna_memoria("preferenze", p, memoria)
#             return f"Preferenze aggiornate: {', '.join(preferenze)}."

#     if messaggio in ["come mi chiamo?", "mi conosci?", "qual è il mio nome?", "sai come mi chiamo?"]:
#         nome = memoria.get("nome")
#         return f"Ti chiami {nome}." if nome else "Non ti conosco ancora."

#     if messaggio in ["dove vivo?", "sai dove vivo?", "sai dove abito?", "qual è il mio indirizzo?"]:
#         indirizzo = memoria.get("indirizzo") or memoria.get("dove_vivo")
#         return f"Vivi a {indirizzo}." if indirizzo else "Non so ancora dove vivi."
#     if messaggio in ["quanti anni ho?", "sai quanti anni ho?", "ho già detto quanti anni ho?"]:
#         eta = memoria.get("eta")
#         return f"Hai {eta} anni." if eta else "Non ho ancora registrato la tua età."
#     if messaggio in ["che preferenze ho?", "cosa ti ho detto che mi piace?", "ricordi cosa mi piace?", "quali sono le mie preferenze?"]:
#         prefs = memoria.get("preferenze", [])
#         if prefs:
#             return f"Preferenze memorizzate: {', '.join(prefs)}."
#         else:
#             return "Non ho ancora memorizzato nessuna preferenza."

#     if messaggio in [
#         "quali scuole ho frequentato?",
#         "che scuola ho fatto?",
#         "dove ho studiato?",
#         "sai dove ho studiato?",
#         "dove ho fatto le superiori?",
#         "qual è la mia scuola?",
#     ]:
#         scuole = memoria.get("scuole")
#         if scuole:
#             return f"Hai frequentato: {scuole}."
#         else:
#             return "Non mi hai ancora detto dove hai studiato."


#     # Navigazione tra cartelle
#     if messaggio.startswith("entra nella cartella"):
#         nome = messaggio.replace("entra nella cartella", "").strip().replace(" ", "_")

#         # Prima prova a entrare nella cartella partendo dalla corrente
#         risposta = aggiorna_percorso(nome)
#         if "non esiste" not in risposta:
#             return risposta

#        # Se fallisce, prova a entrare nelle cartelle principali
#         for cartella_base in CARTELLE:
#             percorso = os.path.join(BASE_DIR, cartella_base, nome)
#             if os.path.isdir(percorso):
#                 global cartella_corrente
#                 cartella_corrente = percorso
#                 return f"📁 Sei ora nella cartella '{nome}' in '{cartella_base}'."

#         return f"❌ La cartella '{nome}' non è stata trovata né nella cartella corrente né in progetti, eventi o appunti."


#     if messaggio in ["dove mi trovo?", "dove sono?", "cartella attuale"]:
#         return mostra_cartella_attuale()

#     if messaggio in ["torna indietro"]:
#         return torna_indietro()

#     if messaggio in ["torna alla root", "vai alla root"]:
#         return torna_alla_root()

#     if messaggio.startswith("crea una nuova cartella"):
#         nome = messaggio.replace("crea una nuova cartella", "").strip()
#         return crea_cartella(nome)

#     if messaggio.startswith("crea un file"):
#         nome = messaggio.replace("crea un file", "").strip()
#         return crea_file(nome, da_telegram=da_telegram)

#     if messaggio in ["elenca i file", "elenca i contenuti", "mostra cartella"]:
#         return elenca_elementi()

#     # Gestione file/appunti/progetti/eventi
#     risposta_file = gestisci_file(messaggio, da_telegram)
#     if risposta_file:
#         return risposta_file

#     # Risposte preimpostate
#     if messaggio in RISPOSTE_PREIMPOSTATE:
#         return RISPOSTE_PREIMPOSTATE[messaggio]

#     # Lettura file
#     if messaggio.startswith("leggi file"):
#         nome = messaggio.replace("leggi file", "").strip().replace(" ", "_")
#         try:
#             with open(os.path.join(cartella_corrente, nome), 'r') as f:
#                 return f.read()
#         except FileNotFoundError:
#             return f"❌ File '{nome}' non trovato."
#         except Exception as e:
#             return f"❌ Errore durante la lettura del file: {str(e)}"

#     # Altrimenti GPT
#     return chiedi_a_gpt(messaggio)
import os
import re
import platform
import shutil
from gpt_module import chiedi_a_gpt
from risposte_preimpostate import RISPOSTE_PREIMPOSTATE
from memory_manager import carica_memoria, aggiorna_memoria, reset_memoria, salva_memoria

BASE_DIR = os.path.expanduser("~/J.A.R.V.I.S/Jarvis")
CARTELLE = ["progetti", "eventi", "appunti"]
for c in CARTELLE:
    os.makedirs(os.path.join(BASE_DIR, c), exist_ok=True)

memoria = carica_memoria()
cartella_corrente = BASE_DIR

def apri_editor(percorso_file):
    editor = "notepad" if platform.system() == "Windows" else "nano"
    os.system(f'{editor} "{percorso_file}"')

def aggiorna_percorso(nome):
    global cartella_corrente
    nuovo_path = os.path.join(cartella_corrente, nome)
    if os.path.isdir(nuovo_path):
        cartella_corrente = nuovo_path
        with open(os.path.expanduser("~/.jarvis_path"), "w") as f:
            f.write(cartella_corrente)
        return f"📁 Sei ora nella cartella '{nome}'."
    return f"❌ La cartella '{nome}' non esiste."

def torna_indietro():
    global cartella_corrente
    if cartella_corrente != BASE_DIR:
        cartella_corrente = os.path.dirname(cartella_corrente)
        with open(os.path.expanduser("~/.jarvis_path"), "w") as f:
            f.write(cartella_corrente)
        return f"🔙 Tornato indietro a '{os.path.basename(cartella_corrente)}'."
    return "🔙 Sei già nella root."

def torna_alla_root():
    global cartella_corrente
    cartella_corrente = BASE_DIR
    with open(os.path.expanduser("~/.jarvis_path"), "w") as f:
        f.write(cartella_corrente)
    return "📂 Tornato alla root principale."

def mostra_cartella_attuale():
    return f"📌 Ti trovi in '{cartella_corrente}'."

def elenca_elementi():
    elementi = os.listdir(cartella_corrente)
    if elementi:
        elenco = f"📁 Contenuto di '{cartella_corrente}':\n"
        for e in elementi:
            tipo = "📂" if os.path.isdir(os.path.join(cartella_corrente, e)) else "📄"
            elenco += f" - {tipo} {e}\n"
        return elenco
    return "📭 La cartella è vuota."

def crea_cartella(nome):
    path = os.path.join(cartella_corrente, nome)
    if not os.path.exists(path):
        os.makedirs(path)
        return f"📂 Cartella '{nome}' creata."
    return f"⚠️ La cartella '{nome}' esiste già."

def crea_file(nome, da_telegram=False):
    path = os.path.join(cartella_corrente, nome)
    if not os.path.exists(path):
        with open(path, "w") as f:
            f.write("")
        apri_editor(path)
        return f"📄 File '{nome}' creato."
    return f"⚠️ Il file '{nome}' esiste già."

def estrai_preferenze(frase):
    frase = frase.lower().strip()
    pattern_inizio = r"^(mi piace|mi piacciono|adoro|preferisco)\s+(.*)"
    match = re.match(pattern_inizio, frase)
    if match:
        contenuto = match.group(2)
        contenuto = re.sub(r"[.!?;:]+$", "", contenuto).strip()
        if any(neg in contenuto for neg in ["non", "di no", "per niente", "affatto", "odio"]):
            return []
        return [p.strip() for p in re.split(r",|\s+e\s+|\s+o\s+|\s+oppure\s+", contenuto) if len(p.strip()) > 2]
    return []

def gestisci_input(messaggio, da_telegram=False):
    global memoria
    messaggio = messaggio.lower().strip()

    if messaggio == "protocollo tabula rasa":
        reset_memoria()
        memoria = carica_memoria()
        return "🧹 Protocollo Tabula Rasa attivato."

    if "mi chiamo" in messaggio and "come mi chiamo" not in messaggio:
        nome = messaggio.replace("mi chiamo", "").strip().capitalize()
        aggiorna_memoria("nome", nome, memoria)
        return f"Piacere di conoscerti, {nome}."

    if "ho" in messaggio and "anni" in messaggio:
        eta = ''.join(filter(str.isdigit, messaggio))
        if eta:
            aggiorna_memoria("eta", eta, memoria)
            return f"Età salvata: {eta} anni."

    if "vivo a" in messaggio:
        luogo = messaggio.split("vivo a")[-1].strip().capitalize()
        aggiorna_memoria("dove_vivo", luogo, memoria)
        return f"Vivi a {luogo}."

    if messaggio.startswith(("mi piace", "mi piacciono", "amo", "adoro", "preferisco")):
        preferenze = estrai_preferenze(messaggio)
        if preferenze:
            for p in preferenze:
                aggiorna_memoria("preferenze", p, memoria)
            return f"Preferenze aggiornate: {', '.join(preferenze)}."

    if messaggio in ["come mi chiamo?", "mi conosci?", "qual è il mio nome?", "sai come mi chiamo?"]:
        nome = memoria.get("nome")
        return f"Ti chiami {nome}." if nome else "Non ti conosco ancora."

    if messaggio in ["quanti anni ho?", "sai quanti anni ho?"]:
        eta = memoria.get("eta")
        return f"Hai {eta} anni." if eta else "Non ho ancora registrato la tua età."

    if messaggio in ["dove vivo?", "qual è il mio indirizzo?"]:
        luogo = memoria.get("dove_vivo")
        return f"Vivi a {luogo}." if luogo else "Non so ancora dove vivi."

    if messaggio.startswith("entra nella cartella"):
        nome = messaggio.replace("entra nella cartella", "").strip()
        return aggiorna_percorso(nome)

    if messaggio in ["dove mi trovo?", "dove sono?", "cartella attuale"]:
        return mostra_cartella_attuale()

    if messaggio in ["torna indietro"]:
        return torna_indietro()

    if messaggio in ["torna alla root", "vai alla root"]:
        return torna_alla_root()

    if messaggio.startswith("crea una nuova cartella"):
        nome = messaggio.replace("crea una nuova cartella", "").strip()
        return crea_cartella(nome)

    if messaggio.startswith("crea un file"):
        nome = messaggio.replace("crea un file", "").strip()
        return crea_file(nome)

    if messaggio in ["elenca i file", "elenca i contenuti", "mostra cartella"]:
        return elenca_elementi()

    if messaggio in RISPOSTE_PREIMPOSTATE:
        return RISPOSTE_PREIMPOSTATE[messaggio]

    return chiedi_a_gpt(messaggio)
