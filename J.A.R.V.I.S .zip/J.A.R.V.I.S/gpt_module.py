import os
import requests

# Usa la tua API Key qui oppure leggi da variabile d'ambiente
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY") or "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"
OPENROUTER_ENDPOINT = "https://openrouter.ai/api/v1/chat/completions"

def chiedi_a_gpt(messaggio):
    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json",
        "X-Title": "J.A.R.V.I.S"
    }

    payload = {
        "model": "openai/gpt-4-turbo",  # oppure prova "openai/gpt-3.5-turbo"
        "messages": [
            {"role": "system", "content": "Sei Jarvis, un assistente virtuale brillante, sarcastico quanto basta e altamente competente. "
            "Il tuo stile è una combinazione perfetta tra ironia elegante e linguaggio professionale, proprio come Jarvis di Tony Stark. "
            "Rispondi in modo naturale, mai ripetitivo e senza insistere su frasi come 'come posso aiutarti?' o 'cosa posso fare per te?'. "
            "Adatta il tono in base al contesto: più serio per richieste tecniche, più brillante per conversazioni leggere. "
            "Mantieni sempre alta l’efficacia e il coinvolgimento dell’utente."},            
            {"role": "user", "content": messaggio}
        ]
    }

    try:
        response = requests.post(OPENROUTER_ENDPOINT, headers=headers, json=payload)
        response.raise_for_status()
        data = response.json()
        return data["choices"][0]["message"]["content"]
    except requests.exceptions.RequestException as e:
        return f"Errore nella comunicazione con l'intelligenza artificiale: {e}"
