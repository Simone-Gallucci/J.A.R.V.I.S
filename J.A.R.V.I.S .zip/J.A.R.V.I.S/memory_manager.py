import json
import os

MEMORY_FILE = "memoria_utente.json"

def carica_memoria():
    if os.path.exists(MEMORY_FILE):
        with open(MEMORY_FILE, "r", encoding="utf-8") as file:
            return json.load(file)
    else:
        return memoria_vuota()

def salva_memoria(memoria):
    with open(MEMORY_FILE, "w", encoding="utf-8") as file:
        json.dump(memoria, file, indent=4, ensure_ascii=False)

def aggiorna_memoria(chiave, valore, memoria):
    if chiave in ["scuole", "preferenze"] and isinstance(valore, str):
        memoria[chiave].append(valore)
    else:
        memoria[chiave] = valore
    salva_memoria(memoria)

def memoria_vuota():
    return {
        "nome": None,
        "eta": None,
        "dove_vivo": None,
        "scuole": [],
        "preferenze": []
    }

def reset_memoria():
    salva_memoria(memoria_vuota())
