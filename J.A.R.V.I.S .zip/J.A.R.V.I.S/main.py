import os
import sys
from core import gestisci_input
from memory_manager import carica_memoria
from datetime import datetime
import readline
import os
import atexit

ROSSO = '\033[91m'
BLU = '\033[94m'
RESET = '\033[0m'

# Cronologia
histfile = os.path.expanduser("~/.jarvis_history")
try:
    readline.read_history_file(histfile)
except FileNotFoundError:
    pass
atexit.register(readline.write_history_file, histfile)

# Percorso corrente
percorso_path = os.path.expanduser("~/.jarvis_path")
if os.path.exists(percorso_path):
    with open(percorso_path, "r") as f:
        cartella_corrente = f.read().strip()
else:
    cartella_corrente = "Jarvis"
def pulisci_schermo():
    os.system("cls" if os.name == "nt" else "clear")
# Loop principale
def main():
    pulisci_schermo()
    print(f"{BLU}Inizializzazione sistema...{RESET}")
    print(f"{BLU}Caricamento funzionalità...{RESET}")
    print(f"{BLU}Accesso al sistema centrale...{RESET}")    
    try:
        while True:
            messaggio = input(f"{ROSSO}Tu: {RESET}").strip()
            risposta = gestisci_input(messaggio)
            if risposta == "Chiusura richiesta.":
                with open(".jarvis_path", "w") as f:
                    f.write(cartella_corrente)
                pulisci_schermo()
                print(f"{BLU}Jarvis: A presto, signore.{RESET}")
                break
            print(f"{BLU}Jarvis: {risposta}{RESET}")
    except KeyboardInterrupt:
        with open(".jarvis_path", "w") as f:
            f.write(cartella_corrente)
        pulisci_schermo()
        print(f"\n{BLU}Jarvis: Interruzione rilevata. Arrivederci, signore.>{RESET}")  
        sys.exit(0)

if __name__ == "__main__":
    main()
